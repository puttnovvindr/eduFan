@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Welcome to EduFun</h1>

        <div class="row">
            @foreach ($categories as $category)
                <div class="col-md-6">
                    <div class="card mb-4">
                        <img src="https://via.placeholder.com/400x200" class="card-img-top" alt="Image for {{ $category->name }}">
                        <div class="card-body">
                            <h5 class="card-title">{{ $category->name }}</h5>
                            <p class="card-text">
                                Here is an article related to {{ $category->name }}. You can read more details by clicking the button below.
                            </p>
                            <a href="{{ route('category.show', ['category' => $category->name]) }}" class="btn btn-primary">Read More...</a>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
@endsection
