@extends('layouts.app')

@section('content')
    <h1>Writers</h1>
    <ul>
        @foreach($writers as $writer)
            <li>
                <h4>{{ $writer['name'] }}</h4>
                <ul>
                    @foreach($writer['articles'] as $article)
                        <li><a href="#">{{ $article }}</a></li>
                    @endforeach
                </ul>
            </li>
        @endforeach
    </ul>
@endsection
