@extends('layouts.app')

@section('content')
    <h1>Detail Materi untuk Kategori: {{ implode(', ', $categoryDetails) }}</h1>

    @foreach($materialDetails as $subject => $materials)
        <h3>{{ $subject }}</h3>
        <ul>
            @foreach($materials as $material)
                <li>{{ $material }}</li>
            @endforeach
        </ul>
    @endforeach
@endsection
