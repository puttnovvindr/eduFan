@extends('layouts.app')

@section('content')
    <h1>About Us</h1>
    <p>EduFun is a platform for free learning materials related to IT courses!</p>
@endsection
