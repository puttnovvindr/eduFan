@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Welcome to EduFun</h1>

        <div class="row">
            @foreach ($categories as $category)
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h5 class="card-title">{{ $category }}</h5>  <!-- Tidak perlu akses 'name' lagi -->
                            <p class="card-text">
                                Here is an article related to {{ $category }}. You can read more details by clicking the button below.
                            </p>
                            <a href="{{ route('category.show', ['category' => $category]) }}" class="btn btn-primary">Read More...</a>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
@endsection
