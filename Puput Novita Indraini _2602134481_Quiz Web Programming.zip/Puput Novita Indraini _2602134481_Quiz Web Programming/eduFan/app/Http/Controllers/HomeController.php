<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index()
    {
        // Ambil semua kategori untuk ditampilkan di Home
        $categories = Category::all();
        return view('home', compact('categories'));
    }
}


