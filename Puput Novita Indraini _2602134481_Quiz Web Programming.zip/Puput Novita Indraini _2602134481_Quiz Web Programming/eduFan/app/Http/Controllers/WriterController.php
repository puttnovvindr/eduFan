<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class WriterController extends Controller
{
    public function index()
    {
        $writers = [
            ['name' => 'John Doe', 'articles' => ['ML 101', 'Deep Learning Basics']],
            ['name' => 'Jane Smith', 'articles' => ['Network Security 101', 'Tech Advances']]
        ];

        return view('writers', compact('writers'));
    }
}
