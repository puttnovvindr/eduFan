<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Detail;
use Illuminate\Http\Request;

class DetailController extends Controller
{
    public function show($id)
    {
        $categoryDetails = Category::getDetails($id);
        $materialDetails = [];

        foreach ($categoryDetails as $detail) {
            $materialDetails[$detail] = Detail::getMaterial($detail);
        }

        return view('detail', compact('categoryDetails', 'materialDetails'));
    }
}
