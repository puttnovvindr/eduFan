<?php

namespace App\Models;

class Detail
{
    // Mengambil materi berdasarkan mata kuliah
    public static function getMaterial($subject)
    {
        $materials = [
            'Machine Learning' => [
                'Introduction to ML',
                'Supervised vs Unsupervised Learning',
                'Algorithms in Machine Learning'
            ],
            'Deep Learning' => [
                'Neural Networks',
                'Deep Learning Models',
                'Training Deep Learning Networks'
            ],
            'Natural Language Processing' => [
                'Text Processing',
                'Sentiment Analysis',
                'Speech Recognition'
            ],
            'Software Security' => [
                'Security Principles',
                'Cryptography Basics',
                'Secure Coding Practices'
            ],
            'Network Administration' => [
                'Network Setup and Configuration',
                'Troubleshooting Networks',
                'Network Protocols'
            ],
            'Popular Network Technology' => [
                'Wi-Fi and 5G',
                'VPNs',
                'Firewalls'
            ]
        ];

        return $materials[$subject] ?? [];
    }
}
