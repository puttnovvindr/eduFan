<?php

namespace App\Models;

class Category
{
    // Menyediakan semua kategori
    public static function all()
    {
        return [
            'Data Science',
            'Network Security'
        ];
    }

    // Menyediakan detail untuk kategori tertentu
    public static function getDetails($category)
    {
        $details = [
            'Data Science' => [
                'Machine Learning',
                'Deep Learning',
                'Natural Language Processing'
            ],
            'Network Security' => [
                'Software Security',
                'Network Administration',
                'Popular Network Technology'
            ]
        ];

        return $details[$category] ?? [];
    }
}
