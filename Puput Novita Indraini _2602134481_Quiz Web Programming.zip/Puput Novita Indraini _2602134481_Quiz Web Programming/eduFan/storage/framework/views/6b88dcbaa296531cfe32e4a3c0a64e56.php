<?php $__env->startSection('content'); ?>
    <h1>About Us</h1>
    <p>EduFun is a platform for free learning materials related to IT courses!</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbook/Documents/eduFan/resources/views/about.blade.php ENDPATH**/ ?>