<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Welcome to EduFun</h1>

        <div class="row">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($category); ?></h5>  <!-- Tidak perlu akses 'name' lagi -->
                            <p class="card-text">
                                Here is an article related to <?php echo e($category); ?>. You can read more details by clicking the button below.
                            </p>
                            <a href="<?php echo e(route('category.show', ['category' => $category])); ?>" class="btn btn-primary">Read More...</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbook/Documents/eduFan/resources/views/home.blade.php ENDPATH**/ ?>