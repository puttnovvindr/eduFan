<?php $__env->startSection('content'); ?>
    <h1>Detail Materi untuk Kategori: <?php echo e(implode(', ', $categoryDetails)); ?></h1>

    <?php $__currentLoopData = $materialDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject => $materials): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h3><?php echo e($subject); ?></h3>
        <ul>
            <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($material); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbook/Documents/eduFan/resources/views/detail.blade.php ENDPATH**/ ?>